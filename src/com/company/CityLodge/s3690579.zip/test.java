import java.util.*;
public class test
{
    public static void main(String args[])
    {
        int x = getIntInput("Enter an integer");
        System.out.println(x);
    }

    public static int getIntInput(String s)
    {
        Scanner scan = new Scanner(System.in);
        System.out.println(s);
        int n = scan.nextInt();
        System.out.println(n);
        return n;
    }
}