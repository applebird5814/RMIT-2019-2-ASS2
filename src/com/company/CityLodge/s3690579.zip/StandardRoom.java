package com.company.CityLodge;

public class StandardRoom extends Room {


    public StandardRoom(String inputroomID, String inputfeature, int inputnumOfBed) {
        super(inputroomID, inputfeature, "Standard", inputnumOfBed);
    }

}